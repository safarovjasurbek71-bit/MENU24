import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'uz' | 'ru' | 'en';

type Translations = {
  [key in Language]: {
    [key: string]: string;
  };
};

const translations: Translations = {
  uz: {
    // Dashboard
    app_subtitle: "Ofitsiant boshqaruv tizimi",
    menu_settings: "Menyu Sozlamalari",
    menu_settings_desc: "Tahrirlash va yangi menyu yaratish",
    new_order: "Yangi Buyurtma",
    new_order_desc: "Stol uchun hisob ochish",
    active_orders: "Faol Buyurtmalar",
    active_orders_desc: "Ochiq stollar ro'yxati",
    import_menu: "Menyu Yuklash",
    creator_phone: "Yaratuvchi raqami",
    password: "Parol",
    download: "Yuklash",
    error_menu_not_found: "Menyu topilmadi yoki parol noto'g'ri",
    success_menu_loaded: "Menyu muvaffaqiyatli yuklandi",
    
    // Menu Settings
    sections: "Bo'limlar",
    dishes: "Taomlar",
    select_section: "Bo'lim tanlang yoki yarating",
    no_sections: "Bo'limlar yo'q",
    no_dishes: "Bu bo'limda taomlar yo'q",
    add: "Qo'shish",
    dish: "Taom",
    new_section: "Yangi Bo'lim",
    new_dish: "Yangi Taom",
    save: "Saqlash",
    dish_name: "Taom nomi",
    price: "Narxi (so'm)",
    upload_image: "Rasm yuklash",
    select_image: "Rasm tanlash",
    gallery_hint: "Telefon galereyasidan rasm tanlang",
    finish_menu: "Menyuni Yakunlash",
    finish_menu_desc: "Ushbu ma'lumotlar orqali boshqa ofitsiantlar menyuni o'z qurilmalariga yuklab olishlari mumkin bo'ladi.",
    your_phone: "Telefon raqamingiz",
    create_password: "Parol o'ylab toping",
    save_finish: "Saqlash va Yakunlash",
    menu_finished: "Menyu Yakunlandi!",
    menu_finished_desc: "Boshqalar endi bu menyuni yuklab olishlari mumkin.",
    saved: "Saqlandi",
    menu_name_updated: "Menyu nomi yangilandi",

    // Create Order
    table_number: "Stol raqami / nomi",
    cart_empty: "Savatcha bo'sh",
    total_items: "Jami taomlar",
    service_charge: "Xizmat haqqi",
    total: "Jami",
    create: "Yaratish",
    search_dish: "Taom qidirish...",
    all: "Barchasi",
    dishes_not_found: "Taomlar topilmadi",
    order_created: "Buyurtma yaratildi",
    enter_table: "Iltimos, stol raqamini kiriting",
    
    // Orders List
    table: "stol",
    close: "Yopish",
    receipt: "Chek",
    print: "Chop etish",
    thank_you: "Xizmatimizdan foydalanganingiz uchun rahmat!",
    payment: "TO'LOV",
    no_active_orders: "Faol buyurtmalar yo'q",
    
    // Reports
    reports: "Hisobotlar",
    reports_desc: "Kunlik savdo va statistika",
    daily_revenue: "Kunlik Savdo",
    total_orders: "Jami Buyurtmalar",
    service_fees: "Xizmat Haqqi",
    today: "Bugun",
    yesterday: "Kecha",
    last_7_days: "Oxirgi 7 kun",
    revenue_chart: "Savdo statistikasi",
    orders_history: "Buyurtmalar Tarixi",
    no_orders_yet: "Hali buyurtmalar yo'q",
    
    // Developer
    developer: "Ishlab chiqaruvchi",
    developed_by: "Dasturchi",
    contact: "Aloqa",
    email: "Email",
    phone: "Telefon",

    // General
    error: "Xatolik",
    success: "Muvaffaqiyatli",
    cancel: "Bekor qilish",
    delete: "O'chirish"
  },
  ru: {
    // Dashboard
    app_subtitle: "Система управления для официантов",
    menu_settings: "Настройки Меню",
    menu_settings_desc: "Редактирование и создание меню",
    new_order: "Новый Заказ",
    new_order_desc: "Открыть счет для стола",
    active_orders: "Активные Заказы",
    active_orders_desc: "Список открытых столов",
    import_menu: "Загрузить Меню",
    creator_phone: "Номер создателя",
    password: "Пароль",
    download: "Загрузить",
    error_menu_not_found: "Меню не найдено или неверный пароль",
    success_menu_loaded: "Меню успешно загружено",
    
    // Menu Settings
    sections: "Разделы",
    dishes: "Блюда",
    select_section: "Выберите или создайте раздел",
    no_sections: "Нет разделов",
    no_dishes: "В этом разделе нет блюд",
    add: "Добавить",
    dish: "Блюдо",
    new_section: "Новый Раздел",
    new_dish: "Новое Блюдо",
    save: "Сохранить",
    dish_name: "Название блюда",
    price: "Цена (сум)",
    upload_image: "Загрузить фото",
    select_image: "Выбрать фото",
    gallery_hint: "Выберите фото из галереи",
    finish_menu: "Завершить Меню",
    finish_menu_desc: "С этими данными другие официанты смогут загрузить это меню.",
    your_phone: "Ваш номер телефона",
    create_password: "Придумайте пароль",
    save_finish: "Сохранить и Завершить",
    menu_finished: "Меню Завершено!",
    menu_finished_desc: "Теперь другие могут загрузить это меню.",
    saved: "Сохранено",
    menu_name_updated: "Название меню обновлено",

    // Create Order
    table_number: "Номер стола / имя",
    cart_empty: "Корзина пуста",
    total_items: "Всего блюд",
    service_charge: "Обслуживание",
    total: "Итого",
    create: "Создать",
    search_dish: "Поиск блюд...",
    all: "Все",
    dishes_not_found: "Блюда не найдены",
    order_created: "Заказ создан",
    enter_table: "Пожалуйста, введите номер стола",
    
    // Orders List
    table: "стол",
    close: "Закрыть",
    receipt: "Чек",
    print: "Печать",
    thank_you: "Спасибо, что выбрали нас!",
    payment: "ОПЛАТА",
    no_active_orders: "Нет активных заказов",
    
    // Reports
    reports: "Отчеты",
    reports_desc: "Ежедневные продажи и статистика",
    daily_revenue: "Дневная выручка",
    total_orders: "Всего заказов",
    service_fees: "Обслуживание",
    today: "Сегодня",
    yesterday: "Вчера",
    last_7_days: "Последние 7 дней",
    revenue_chart: "Статистика продаж",
    orders_history: "История заказов",
    no_orders_yet: "Пока нет заказов",
    
    // Developer
    developer: "Разработчик",
    developed_by: "Разработано",
    contact: "Контакты",
    email: "Email",
    phone: "Телефон",

    // General
    error: "Ошибка",
    success: "Успешно",
    cancel: "Отмена",
    delete: "Удалить"
  },
  en: {
    // Dashboard
    app_subtitle: "Waiter Management System",
    menu_settings: "Menu Settings",
    menu_settings_desc: "Edit and create menu",
    new_order: "New Order",
    new_order_desc: "Open tab for table",
    active_orders: "Active Orders",
    active_orders_desc: "List of open tables",
    import_menu: "Import Menu",
    creator_phone: "Creator Phone",
    password: "Password",
    download: "Download",
    error_menu_not_found: "Menu not found or incorrect password",
    success_menu_loaded: "Menu loaded successfully",
    
    // Menu Settings
    sections: "Sections",
    dishes: "Dishes",
    select_section: "Select or create a section",
    no_sections: "No sections",
    no_dishes: "No dishes in this section",
    add: "Add",
    dish: "Dish",
    new_section: "New Section",
    new_dish: "New Dish",
    save: "Save",
    dish_name: "Dish name",
    price: "Price (sum)",
    upload_image: "Upload Image",
    select_image: "Select Image",
    gallery_hint: "Select image from gallery",
    finish_menu: "Finish Menu",
    finish_menu_desc: "Others can download this menu using these credentials.",
    your_phone: "Your Phone Number",
    create_password: "Create Password",
    save_finish: "Save and Finish",
    menu_finished: "Menu Finished!",
    menu_finished_desc: "Others can now download this menu.",
    saved: "Saved",
    menu_name_updated: "Menu name updated",

    // Create Order
    table_number: "Table Number / Name",
    cart_empty: "Cart is empty",
    total_items: "Total Items",
    service_charge: "Service Charge",
    total: "Total",
    create: "Create",
    search_dish: "Search dishes...",
    all: "All",
    dishes_not_found: "No dishes found",
    order_created: "Order created",
    enter_table: "Please enter table number",
    
    // Orders List
    table: "table",
    close: "Close",
    receipt: "Receipt",
    print: "Print",
    thank_you: "Thank you for choosing us!",
    payment: "PAYMENT",
    no_active_orders: "No active orders",
    
    // Reports
    reports: "Reports",
    reports_desc: "Daily sales and statistics",
    daily_revenue: "Daily Revenue",
    total_orders: "Total Orders",
    service_fees: "Service Fees",
    today: "Today",
    yesterday: "Yesterday",
    last_7_days: "Last 7 days",
    revenue_chart: "Sales Statistics",
    orders_history: "Order History",
    no_orders_yet: "No orders yet",
    
    // Developer
    developer: "Developer",
    developed_by: "Developed by",
    contact: "Contact",
    email: "Email",
    phone: "Phone",

    // General
    error: "Error",
    success: "Success",
    cancel: "Cancel",
    delete: "Delete"
  }
};

type LanguageContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('uz');

  useEffect(() => {
    const saved = localStorage.getItem('menu24_language') as Language;
    if (saved && (saved === 'uz' || saved === 'ru' || saved === 'en')) {
      setLanguage(saved);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('menu24_language', lang);
  };

  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
