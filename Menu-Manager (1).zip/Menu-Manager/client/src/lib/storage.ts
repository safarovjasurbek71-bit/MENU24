import { useState, useEffect } from "react";

// Types
export type MenuItem = {
  id: string;
  name: string;
  price: number;
  image?: string;
  categoryId: string;
};

export type Category = {
  id: string;
  name: string;
};

export type OrderItem = MenuItem & {
  quantity: number;
};

export type Order = {
  id: string;
  tableNumber: string;
  items: OrderItem[];
  total: number;
  serviceCharge: number;
  createdAt: number;
  status: 'active' | 'completed';
};

export type CloudMenu = {
  phone: string;
  password: string;
  categories: Category[];
  items: MenuItem[];
  menuName: string;
};

// Mock Storage Keys
const STORAGE_KEYS = {
  CATEGORIES: 'menu24_categories',
  ITEMS: 'menu24_items',
  ORDERS: 'menu24_orders',
  MENU_NAME: 'menu24_current_menu_name',
  CLOUD_MENUS: 'menu24_cloud_menus' // New key for storing "cloud" menus locally
};

// Helper to manage offline data
export const storage = {
  getCategories: (): Category[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    return data ? JSON.parse(data) : [];
  },
  saveCategories: (categories: Category[]) => {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  },
  getItems: (): MenuItem[] => {
    const data = localStorage.getItem(STORAGE_KEYS.ITEMS);
    return data ? JSON.parse(data) : [];
  },
  saveItems: (items: MenuItem[]) => {
    localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(items));
  },
  getOrders: (): Order[] => {
    const data = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return data ? JSON.parse(data) : [];
  },
  saveOrders: (orders: Order[]) => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  },
  getMenuName: (): string => {
    return localStorage.getItem(STORAGE_KEYS.MENU_NAME) || "Asosiy Menyu";
  },
  saveMenuName: (name: string) => {
    localStorage.setItem(STORAGE_KEYS.MENU_NAME, name);
  },
  
  // "Cloud" Simulation
  publishMenu: (menu: CloudMenu) => {
    const clouds = localStorage.getItem(STORAGE_KEYS.CLOUD_MENUS);
    const menus: CloudMenu[] = clouds ? JSON.parse(clouds) : [];
    
    // Check if exists and update, or add new
    const existingIndex = menus.findIndex(m => m.phone === menu.phone && m.password === menu.password);
    
    if (existingIndex >= 0) {
      menus[existingIndex] = menu;
    } else {
      menus.push(menu);
    }
    
    localStorage.setItem(STORAGE_KEYS.CLOUD_MENUS, JSON.stringify(menus));
  },
  
  fetchMenu: (phone: string, password: string): CloudMenu | null => {
    const clouds = localStorage.getItem(STORAGE_KEYS.CLOUD_MENUS);
    if (!clouds) return null;
    
    const menus: CloudMenu[] = JSON.parse(clouds);
    return menus.find(m => m.phone === phone && m.password === password) || null;
  }
};
