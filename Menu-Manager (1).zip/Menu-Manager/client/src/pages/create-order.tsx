import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, ShoppingBag, Plus, Minus, Search, Check, Image as ImageIcon } from "lucide-react";
import { storage, type Category, type MenuItem, type OrderItem } from "@/lib/storage";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetFooter } from "@/components/ui/sheet";
import { useLanguage } from "@/lib/i18n";

export default function CreateOrder() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [tableNumber, setTableNumber] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [serviceCharge, setServiceCharge] = useState(0); // Fixed amount
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { t } = useLanguage();

  useEffect(() => {
    setCategories(storage.getCategories());
    const loadedItems = storage.getItems();
    setItems(loadedItems);
    if (storage.getCategories().length > 0) {
      setActiveCategory(storage.getCategories()[0].id);
    }
  }, []);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === itemId) {
        const newQty = Math.max(0, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory ? item.categoryId === activeCategory : true;
    return matchesSearch && matchesCategory;
  });

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const finalTotal = cartTotal + serviceCharge;

  const handleCreateOrder = () => {
    if (!tableNumber) {
      toast({ title: t('error'), description: t('enter_table'), variant: "destructive" });
      return;
    }
    if (cart.length === 0) {
      toast({ title: t('error'), description: t('cart_empty'), variant: "destructive" });
      return;
    }

    const newOrder = {
      id: Date.now().toString(),
      tableNumber,
      items: cart,
      total: finalTotal,
      serviceCharge,
      createdAt: Date.now(),
      status: 'active' as const
    };

    const orders = storage.getOrders();
    storage.saveOrders([...orders, newOrder]);
    
    toast({ title: t('order_created'), description: `${tableNumber}-${t('table')}` });
    setLocation("/orders");
  };

  return (
    <div className="h-screen bg-background flex flex-col max-w-md mx-auto overflow-hidden">
      {/* Header */}
      <div className="bg-white border-b p-3 flex items-center gap-3 shadow-sm z-10">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <Input 
          placeholder={t('table_number')}
          value={tableNumber}
          onChange={(e) => setTableNumber(e.target.value)}
          className="flex-1 bg-secondary/50 border-none focus-visible:ring-1 focus-visible:ring-primary"
        />
        <Sheet>
          <SheetTrigger asChild>
            <Button className="relative" size="icon" variant={cart.length > 0 ? "default" : "outline"}>
              <ShoppingBag className="w-5 h-5" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                  {cart.reduce((a, b) => a + b.quantity, 0)}
                </span>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent className="w-full sm:max-w-md flex flex-col h-full">
            <SheetHeader>
              <SheetTitle>Buyurtma: {tableNumber || "Nomsiz"}</SheetTitle>
            </SheetHeader>
            
            <div className="flex-1 overflow-y-auto py-4">
              {cart.length === 0 ? (
                <div className="text-center text-muted-foreground py-10">{t('cart_empty')}</div>
              ) : (
                <div className="space-y-4">
                  {cart.map(item => (
                    <div key={item.id} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-muted-foreground">{item.price.toLocaleString()} x {item.quantity}</p>
                      </div>
                      <div className="flex items-center gap-3 bg-secondary rounded-full p-1">
                        <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:bg-white rounded-full transition-colors">
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="text-sm font-medium w-4 text-center">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-white rounded-full transition-colors">
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="border-t pt-4 space-y-4 mt-auto">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>{t('total_items')}:</span>
                  <span>{cartTotal.toLocaleString()} so'm</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>{t('service_charge')}:</span>
                  <Input 
                    type="number" 
                    value={serviceCharge || ""} 
                    onChange={(e) => setServiceCharge(Number(e.target.value))}
                    placeholder="0"
                    className="w-24 h-8 text-right"
                  />
                </div>
                <div className="flex justify-between font-bold text-lg pt-2 border-t">
                  <span>{t('total')}:</span>
                  <span className="text-primary">{finalTotal.toLocaleString()} so'm</span>
                </div>
              </div>
              <SheetFooter>
                <Button className="w-full py-6 text-lg font-bold" onClick={handleCreateOrder}>
                  {t('create')} <Check className="ml-2 w-5 h-5" />
                </Button>
              </SheetFooter>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Search & Categories */}
      <div className="p-3 space-y-3 bg-background">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder={t('search_dish')} 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 bg-white"
          />
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
              !activeCategory 
                ? "bg-primary text-primary-foreground" 
                : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
            }`}
          >
            {t('all')}
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
                activeCategory === cat.id 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Menu Grid */}
      <div className="flex-1 overflow-y-auto p-3 bg-secondary/30">
        <div className="grid grid-cols-2 gap-3">
          {filteredItems.map(item => (
            <motion.button
              key={item.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => addToCart(item)}
              className="bg-white rounded-xl shadow-sm border text-left flex flex-col h-full overflow-hidden"
            >
              <div className="h-24 w-full bg-secondary flex items-center justify-center overflow-hidden relative">
                {item.image ? (
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                ) : (
                  <ImageIcon className="w-8 h-8 text-muted-foreground/30" />
                )}
                <div className="absolute bottom-2 right-2 bg-primary/10 text-primary p-1.5 rounded-full shadow-sm bg-white/90 backdrop-blur-sm">
                  <Plus className="w-4 h-4" />
                </div>
              </div>
              <div className="p-3 flex-1 flex flex-col">
                <h4 className="font-medium text-sm line-clamp-2 mb-1 leading-tight">{item.name}</h4>
                <p className="text-xs font-bold text-primary mt-auto">{item.price.toLocaleString()} so'm</p>
              </div>
            </motion.button>
          ))}
        </div>
        {filteredItems.length === 0 && (
          <div className="text-center py-10 text-muted-foreground">
            {t('dishes_not_found')}
          </div>
        )}
      </div>
    </div>
  );
}
