import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { ArrowLeft, Plus, Save, Trash2, FolderPlus, Image as ImageIcon, Utensils, CheckCircle, Lock } from "lucide-react";
import { storage, type Category, type MenuItem } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { useLanguage } from "@/lib/i18n";

export default function MenuSettings() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [menuName, setMenuName] = useState("Asosiy Menyu");
  const { toast } = useToast();
  const { t } = useLanguage();

  // Load data
  useEffect(() => {
    setCategories(storage.getCategories());
    setItems(storage.getItems());
    setMenuName(storage.getMenuName());
  }, []);

  // Save handlers
  const handleSaveMenuName = () => {
    storage.saveMenuName(menuName);
    toast({ title: t('saved'), description: t('menu_name_updated') });
  };

  const addCategory = (name: string) => {
    const newCat = { id: Date.now().toString(), name };
    const updated = [...categories, newCat];
    setCategories(updated);
    storage.saveCategories(updated);
    setActiveCategory(newCat.id);
  };

  const addItem = (name: string, price: number, image: string) => {
    if (!activeCategory) return;
    const newItem: MenuItem = {
      id: Date.now().toString(),
      name,
      price,
      image,
      categoryId: activeCategory
    };
    const updated = [...items, newItem];
    setItems(updated);
    storage.saveItems(updated);
  };

  const deleteItem = (id: string) => {
    const updated = items.filter(i => i.id !== id);
    setItems(updated);
    storage.saveItems(updated);
  };

  const filteredItems = items.filter(i => i.categoryId === activeCategory);

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto relative pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b px-4 py-3 flex items-center gap-3">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <Input 
          value={menuName} 
          onChange={(e) => setMenuName(e.target.value)} 
          className="border-none font-bold text-lg bg-transparent h-auto p-0 focus-visible:ring-0"
        />
        <Button size="sm" variant="ghost" onClick={handleSaveMenuName}>
          <Save className="w-4 h-4 text-primary" />
        </Button>
      </div>

      <div className="p-4 flex-1 flex flex-col">
        {/* Categories */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-muted-foreground text-sm uppercase tracking-wider">{t('sections')}</h3>
            <AddCategoryDialog onAdd={addCategory} />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
                  activeCategory === cat.id 
                    ? "bg-primary text-primary-foreground" 
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {cat.name}
              </button>
            ))}
            {categories.length === 0 && (
              <span className="text-sm text-muted-foreground italic">{t('no_sections')}</span>
            )}
          </div>
        </div>

        {/* Items Grid */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-muted-foreground text-sm uppercase tracking-wider">
              {categories.find(c => c.id === activeCategory)?.name || t('dishes')}
            </h3>
            {activeCategory && <AddItemDialog onAdd={addItem} />}
          </div>

          {!activeCategory ? (
            <div className="flex flex-col items-center justify-center h-40 text-muted-foreground text-center border-2 border-dashed rounded-xl">
              <FolderPlus className="w-8 h-8 mb-2 opacity-50" />
              <p>{t('select_section')}</p>
            </div>
          ) : filteredItems.length === 0 ? (
             <div className="flex flex-col items-center justify-center h-40 text-muted-foreground text-center border-2 border-dashed rounded-xl">
              <UtensilsIcon className="w-8 h-8 mb-2 opacity-50" />
              <p>{t('no_dishes')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {filteredItems.map(item => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={item.id} 
                  className="bg-white rounded-xl shadow-sm overflow-hidden border relative group"
                >
                  <div className="h-24 bg-secondary flex items-center justify-center overflow-hidden">
                    {item.image ? (
                      <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                    ) : (
                      <ImageIcon className="w-8 h-8 text-muted-foreground/30" />
                    )}
                  </div>
                  <div className="p-3">
                    <div className="flex justify-between items-start">
                      <h4 className="font-medium text-sm line-clamp-2 leading-tight">{item.name}</h4>
                      <button 
                        onClick={() => deleteItem(item.id)}
                        className="text-destructive opacity-0 group-hover:opacity-100 transition-opacity -mr-1 -mt-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-primary font-bold mt-1">{item.price.toLocaleString()} so'm</p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Finish Menu Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur border-t max-w-md mx-auto">
        <PublishMenuDialog 
          menuName={menuName} 
          categories={categories} 
          items={items} 
        />
      </div>
    </div>
  );
}

function PublishMenuDialog({ menuName, categories, items }: { menuName: string, categories: Category[], items: MenuItem[] }) {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const { t } = useLanguage();

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone && password) {
      storage.publishMenu({
        phone,
        password,
        menuName,
        categories,
        items
      });
      toast({ 
        title: t('menu_finished'), 
        description: t('menu_finished_desc') 
      });
      setOpen(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full text-lg font-bold" size="lg">
          <CheckCircle className="w-5 h-5 mr-2" /> {t('finish_menu')}
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[90%] rounded-2xl">
        <DialogHeader>
          <DialogTitle>{t('finish_menu')}</DialogTitle>
        </DialogHeader>
        <div className="text-sm text-muted-foreground mb-2">
          {t('finish_menu_desc')}
        </div>
        <form onSubmit={handlePublish} className="space-y-4 mt-2">
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-medium">{t('your_phone')}</label>
            <Input 
              placeholder="+998901234567" 
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-medium">{t('create_password')}</label>
            <Input 
              type="password"
              placeholder="******" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button type="submit" className="w-full">
            <Lock className="w-4 h-4 mr-2" /> {t('save_finish')}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function AddCategoryDialog({ onAdd }: { onAdd: (name: string) => void }) {
  const [name, setName] = useState("");
  const [open, setOpen] = useState(false);
  const { t } = useLanguage();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onAdd(name);
      setName("");
      setOpen(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="h-7 text-xs">
          <Plus className="w-3 h-3 mr-1" /> {t('add')}
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[90%] rounded-2xl">
        <DialogHeader>
          <DialogTitle>{t('new_section')}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <Input 
            placeholder="Masalan: Salatlar" 
            value={name} 
            onChange={(e) => setName(e.target.value)}
            autoFocus
          />
          <Button type="submit" className="w-full">{t('save')}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function AddItemDialog({ onAdd }: { onAdd: (name: string, price: number, image: string) => void }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");
  const [open, setOpen] = useState(false);
  const { t } = useLanguage();

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && price) {
      onAdd(name, Number(price), image);
      setName("");
      setPrice("");
      setImage("");
      setOpen(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="h-7 text-xs">
          <Plus className="w-3 h-3 mr-1" /> {t('dish')}
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[90%] rounded-2xl">
        <DialogHeader>
          <DialogTitle>{t('new_dish')}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium mb-1.5 block text-muted-foreground">{t('upload_image')}</label>
              <div className="flex items-center gap-3">
                <div className="h-16 w-16 rounded-lg bg-secondary flex items-center justify-center overflow-hidden border relative shrink-0">
                  {image ? (
                    <img src={image} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <ImageIcon className="w-6 h-6 text-muted-foreground/40" />
                  )}
                  <Input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleImageChange} 
                    className="absolute inset-0 opacity-0 cursor-pointer z-10 h-full w-full" 
                  />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground mb-2">{t('gallery_hint')}</p>
                  <div className="relative">
                    <Button type="button" variant="secondary" size="sm" className="h-8 w-full text-xs">
                      {t('select_image')}
                    </Button>
                    <Input 
                      type="file" 
                      accept="image/*" 
                      onChange={handleImageChange} 
                      className="absolute inset-0 opacity-0 cursor-pointer z-10 h-full w-full" 
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Input 
                placeholder={t('dish_name')}
                value={name} 
                onChange={(e) => setName(e.target.value)}
              />
              <Input 
                type="number" 
                placeholder={t('price')} 
                value={price} 
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>
          </div>
          <Button type="submit" className="w-full">{t('add')}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function UtensilsIcon(props: any) {
  return <Utensils {...props} />
}
