import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChefHat, ClipboardList, Plus, Utensils, CloudDownload, Settings, Globe, TrendingUp, Info, Mail, Phone } from "lucide-react";
import { motion } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { storage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/lib/i18n";

export default function Dashboard() {
  const { t, language, setLanguage } = useLanguage();

  return (
    <div className="min-h-screen bg-background p-6 flex flex-col max-w-md mx-auto">
      <header className="mb-8 mt-4 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-primary tracking-tight">MENU24</h1>
          <p className="text-muted-foreground">{t('app_subtitle')}</p>
        </div>
        <div className="flex items-center gap-2">
           <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Globe className="w-5 h-5 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setLanguage('uz')} className={language === 'uz' ? 'bg-secondary' : ''}>
                🇺🇿 O'zbekcha
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage('ru')} className={language === 'ru' ? 'bg-secondary' : ''}>
                🇷🇺 Русский
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage('en')} className={language === 'en' ? 'bg-secondary' : ''}>
                🇬🇧 English
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <AboutDialog />
          <ImportMenuDialog />
        </div>
      </header>

      <main className="flex-1 grid grid-cols-1 gap-4">
        <Link href="/menu">
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Card className="bg-white shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-primary cursor-pointer h-32">
              <CardContent className="flex items-center p-6 h-full">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Settings className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">{t('menu_settings')}</h2>
                  <p className="text-sm text-muted-foreground">{t('menu_settings_desc')}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </Link>

        <Link href="/new-order">
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Card className="bg-primary shadow-lg shadow-primary/20 cursor-pointer h-40">
              <CardContent className="flex flex-col items-center justify-center p-6 h-full text-primary-foreground">
                <div className="bg-white/20 p-4 rounded-full mb-3">
                  <Plus className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold">{t('new_order')}</h2>
                <p className="text-primary-foreground/80 text-sm">{t('new_order_desc')}</p>
              </CardContent>
            </Card>
          </motion.div>
        </Link>

        <div className="grid grid-cols-2 gap-4">
          <Link href="/orders">
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Card className="bg-white shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-emerald-300 cursor-pointer h-32">
                <CardContent className="flex flex-col justify-center items-center p-4 h-full text-center">
                  <div className="bg-emerald-100 p-3 rounded-full mb-2">
                    <ClipboardList className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div>
                    <h2 className="font-semibold text-sm leading-tight">{t('active_orders')}</h2>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </Link>

          <Link href="/reports">
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Card className="bg-white shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-blue-300 cursor-pointer h-32">
                <CardContent className="flex flex-col justify-center items-center p-4 h-full text-center">
                  <div className="bg-blue-100 p-3 rounded-full mb-2">
                    <TrendingUp className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h2 className="font-semibold text-sm leading-tight">{t('reports')}</h2>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </Link>
        </div>
      </main>

      <footer className="mt-8 text-center text-xs text-muted-foreground">
        <p>Offline Mode • v1.3.0</p>
      </footer>
    </div>
  );
}

function AboutDialog() {
  const { t } = useLanguage();
  
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="rounded-full">
          <Info className="w-5 h-5 text-muted-foreground" />
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[90%] rounded-2xl">
        <DialogHeader>
          <DialogTitle>{t('developer')}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center py-4 text-center space-y-4">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-2">
             <span className="text-2xl font-bold text-primary">SJ</span>
          </div>
          
          <div>
            <h3 className="font-bold text-xl">Safarov Jasurbek</h3>
            <p className="text-sm text-muted-foreground">Full Stack Developer</p>
          </div>

          <div className="w-full space-y-3 mt-4 bg-secondary/50 p-4 rounded-xl">
             <div className="flex items-center gap-3">
               <Mail className="w-4 h-4 text-primary" />
               <a href="mailto:safarovjasurbek71@gmail.com" className="text-sm hover:underline">
                 safarovjasurbek71@gmail.com
               </a>
             </div>
             <div className="flex items-center gap-3">
               <Phone className="w-4 h-4 text-primary" />
               <a href="tel:+998990767514" className="text-sm hover:underline">
                 +998 99 076 75 14
               </a>
             </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ImportMenuDialog() {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const { t } = useLanguage();

  const handleImport = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone && password) {
      const menu = storage.fetchMenu(phone, password);
      if (menu) {
        storage.saveCategories(menu.categories);
        storage.saveItems(menu.items);
        storage.saveMenuName(menu.menuName);
        toast({ title: t('success'), description: t('success_menu_loaded') });
        setOpen(false);
        setPhone("");
        setPassword("");
      } else {
        toast({ title: t('error'), description: t('error_menu_not_found'), variant: "destructive" });
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon" className="rounded-full">
          <CloudDownload className="w-5 h-5 text-muted-foreground" />
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[90%] rounded-2xl">
        <DialogHeader>
          <DialogTitle>{t('import_menu')}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleImport} className="space-y-4 mt-2">
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-medium">{t('creator_phone')}</label>
            <Input 
              placeholder="+998901234567" 
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-medium">{t('password')}</label>
            <Input 
              type="password"
              placeholder="******" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button type="submit" className="w-full">{t('download')}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
