import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Clock, Trash2, Receipt, RefreshCcw, Printer } from "lucide-react";
import { storage, type Order } from "@/lib/storage";
import { motion } from "framer-motion";
import { formatDistanceToNow, format } from "date-fns";
import { uz } from "date-fns/locale";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { useLanguage } from "@/lib/i18n";

export default function OrdersList() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [now, setNow] = useState(Date.now());
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const { t } = useLanguage();

  const loadOrders = () => {
    const all = storage.getOrders();
    // Auto delete logic: remove orders older than 2 hours (7200000 ms)
    const TWO_HOURS = 2 * 60 * 60 * 1000;
    const valid = all.filter(o => (Date.now() - o.createdAt) < TWO_HOURS);
    
    if (valid.length !== all.length) {
      storage.saveOrders(valid); // Sync cleanup
    }
    setOrders(valid.sort((a, b) => b.createdAt - a.createdAt));
  };

  useEffect(() => {
    loadOrders();
    const interval = setInterval(() => setNow(Date.now()), 60000); // Update 'time ago' every min
    return () => clearInterval(interval);
  }, []);

  const closeOrder = (id: string) => {
    // In a real app, this would archive it. Here we just remove for "completed" effect or simple delete
    const updated = orders.filter(o => o.id !== id);
    setOrders(updated);
    storage.saveOrders(updated);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto">
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link href="/">
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h1 className="font-bold text-lg">{t('active_orders')}</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={loadOrders}>
          <RefreshCcw className="w-4 h-4" />
        </Button>
      </div>

      <div className="p-4 space-y-4">
        {orders.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <Receipt className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p>{t('no_active_orders')}</p>
          </div>
        ) : (
          orders.map(order => (
            <motion.div 
              key={order.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm border p-4"
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-bold text-lg text-primary">{order.tableNumber}-{t('table')}</h3>
                  <div className="flex items-center text-xs text-muted-foreground mt-1">
                    <Clock className="w-3 h-3 mr-1" />
                    {formatDistanceToNow(order.createdAt, { addSuffix: true, locale: uz })}
                  </div>
                </div>
                <span className="font-bold text-lg">{order.total.toLocaleString()} so'm</span>
              </div>

              <div className="space-y-1 mb-4">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{item.quantity}x {item.name}</span>
                    <span>{(item.price * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
                {order.serviceCharge > 0 && (
                  <div className="flex justify-between text-sm text-emerald-600 font-medium pt-1">
                    <span>{t('service_charge')}</span>
                    <span>+{order.serviceCharge.toLocaleString()}</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 text-destructive hover:text-destructive" onClick={() => closeOrder(order.id)}>
                  <Trash2 className="w-4 h-4 mr-2" /> {t('close')}
                </Button>
                
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="flex-1" onClick={() => setSelectedOrder(order)}>
                      <Receipt className="w-4 h-4 mr-2" /> {t('receipt')}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm mx-auto rounded-xl">
                    {selectedOrder && (
                      <div className="p-4 bg-white">
                        <div className="text-center border-b pb-4 mb-4 border-dashed">
                          <h2 className="font-bold text-xl uppercase tracking-widest">MENU24</h2>
                          <p className="text-xs text-muted-foreground mt-1">Restoran Boshqaruv Tizimi</p>
                          <p className="text-xs text-muted-foreground mt-2">
                            {format(selectedOrder.createdAt, "dd.MM.yyyy HH:mm")}
                          </p>
                        </div>
                        
                        <div className="text-center mb-4">
                          <span className="bg-black text-white px-3 py-1 text-sm font-bold rounded-full">
                            STOL: {selectedOrder.tableNumber}
                          </span>
                        </div>

                        <div className="space-y-2 mb-4 text-sm">
                          {selectedOrder.items.map((item, i) => (
                            <div key={i} className="flex justify-between">
                              <span>{item.name} <span className="text-muted-foreground">x{item.quantity}</span></span>
                              <span>{(item.price * item.quantity).toLocaleString()}</span>
                            </div>
                          ))}
                        </div>

                        <div className="border-t border-dashed pt-2 space-y-1 text-sm">
                          <div className="flex justify-between text-muted-foreground">
                            <span>{t('total')}:</span>
                            <span>{(selectedOrder.total - selectedOrder.serviceCharge).toLocaleString()}</span>
                          </div>
                          {selectedOrder.serviceCharge > 0 && (
                            <div className="flex justify-between text-muted-foreground">
                              <span>{t('service_charge')}:</span>
                              <span>+{selectedOrder.serviceCharge.toLocaleString()}</span>
                            </div>
                          )}
                          <div className="flex justify-between font-bold text-lg mt-2 pt-2 border-t border-dashed">
                            <span>{t('payment')}:</span>
                            <span>{selectedOrder.total.toLocaleString()} so'm</span>
                          </div>
                        </div>

                        <div className="text-center mt-6 text-xs text-muted-foreground uppercase tracking-wider">
                          {t('thank_you')}
                        </div>
                        
                        <Button className="w-full mt-6 hide-on-print" onClick={() => window.print()}>
                          <Printer className="w-4 h-4 mr-2" /> {t('print')}
                        </Button>
                      </div>
                    )}
                  </DialogContent>
                </Dialog>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
