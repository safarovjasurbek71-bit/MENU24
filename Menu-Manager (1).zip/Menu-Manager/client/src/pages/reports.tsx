import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, TrendingUp, Calendar, DollarSign, Wallet } from "lucide-react";
import { storage, type Order } from "@/lib/storage";
import { motion } from "framer-motion";
import { useLanguage } from "@/lib/i18n";
import { format, isSameDay, subDays, startOfDay, endOfDay } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";

export default function Reports() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<'today' | 'yesterday' | 'week'>('today');
  const { t } = useLanguage();

  useEffect(() => {
    // Get all orders (we rely on storage not deleting them now, or we only show what's available)
    setOrders(storage.getOrders());
  }, []);

  const getFilteredOrders = () => {
    const now = new Date();
    let start: Date;
    let end: Date;

    if (selectedPeriod === 'today') {
      start = startOfDay(now);
      end = endOfDay(now);
    } else if (selectedPeriod === 'yesterday') {
      const yesterday = subDays(now, 1);
      start = startOfDay(yesterday);
      end = endOfDay(yesterday);
    } else {
      start = subDays(now, 7);
      end = endOfDay(now);
    }

    return orders.filter(o => o.createdAt >= start.getTime() && o.createdAt <= end.getTime());
  };

  const filteredOrders = getFilteredOrders();
  
  const totalRevenue = filteredOrders.reduce((sum, o) => sum + o.total, 0);
  const totalServiceCharge = filteredOrders.reduce((sum, o) => sum + o.serviceCharge, 0);
  const totalOrders = filteredOrders.length;

  // Prepare chart data
  const chartData = filteredOrders.map(o => ({
    time: format(o.createdAt, "HH:mm"),
    amount: o.total
  }));

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto pb-10">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b px-4 py-3 flex items-center gap-3">
        <Link href="/">
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <h1 className="font-bold text-lg">{t('reports')}</h1>
      </div>

      <div className="p-4 space-y-6">
        {/* Filter Tabs */}
        <div className="flex bg-secondary p-1 rounded-lg">
          <button
            onClick={() => setSelectedPeriod('today')}
            className={`flex-1 py-1.5 text-sm font-medium rounded-md transition-all ${
              selectedPeriod === 'today' ? 'bg-white shadow-sm text-primary' : 'text-muted-foreground'
            }`}
          >
            {t('today')}
          </button>
          <button
            onClick={() => setSelectedPeriod('yesterday')}
            className={`flex-1 py-1.5 text-sm font-medium rounded-md transition-all ${
              selectedPeriod === 'yesterday' ? 'bg-white shadow-sm text-primary' : 'text-muted-foreground'
            }`}
          >
            {t('yesterday')}
          </button>
          <button
            onClick={() => setSelectedPeriod('week')}
            className={`flex-1 py-1.5 text-sm font-medium rounded-md transition-all ${
              selectedPeriod === 'week' ? 'bg-white shadow-sm text-primary' : 'text-muted-foreground'
            }`}
          >
            {t('last_7_days')}
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4 flex flex-col justify-between h-full">
              <div className="bg-emerald-100 w-8 h-8 rounded-full flex items-center justify-center mb-2">
                <DollarSign className="w-4 h-4 text-emerald-600" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">{t('daily_revenue')}</p>
                <h3 className="text-xl font-bold text-emerald-600">{totalRevenue.toLocaleString()}</h3>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 flex flex-col justify-between h-full">
              <div className="bg-blue-100 w-8 h-8 rounded-full flex items-center justify-center mb-2">
                <Wallet className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">{t('service_fees')}</p>
                <h3 className="text-xl font-bold text-blue-600">{totalServiceCharge.toLocaleString()}</h3>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Total Orders Count */}
        <Card className="bg-primary text-primary-foreground">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-2 rounded-lg">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs opacity-80">{t('total_orders')}</p>
                <h3 className="text-2xl font-bold">{totalOrders}</h3>
              </div>
            </div>
            <TrendingUp className="w-8 h-8 opacity-50" />
          </CardContent>
        </Card>

        {/* Chart */}
        {chartData.length > 0 ? (
          <div className="h-64 w-full mt-4">
            <h3 className="font-medium mb-4 text-sm">{t('revenue_chart')}</h3>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(150 60% 45%)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(150 60% 45%)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                <XAxis 
                  dataKey="time" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fontSize: 10, fill: '#888'}} 
                />
                <YAxis 
                  hide={true} 
                />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Area 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="hsl(150 60% 45%)" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorAmount)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-40 flex items-center justify-center border-2 border-dashed rounded-xl text-muted-foreground">
            <p>{t('no_orders_yet')}</p>
          </div>
        )}

        {/* Recent Orders List */}
        <div>
          <h3 className="font-medium mb-3 text-sm">{t('orders_history')}</h3>
          <div className="space-y-2">
            {filteredOrders.map(order => (
              <div key={order.id} className="bg-white p-3 rounded-lg border shadow-sm flex justify-between items-center">
                <div>
                  <p className="font-bold text-sm">{order.tableNumber}-{t('table')}</p>
                  <p className="text-xs text-muted-foreground">{format(order.createdAt, "HH:mm")}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-sm">{order.total.toLocaleString()}</p>
                  {order.serviceCharge > 0 && (
                    <p className="text-[10px] text-emerald-600">+{order.serviceCharge.toLocaleString()}</p>
                  )}
                </div>
              </div>
            ))}
            {filteredOrders.length === 0 && (
               <p className="text-center text-sm text-muted-foreground py-4">{t('no_orders_yet')}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
